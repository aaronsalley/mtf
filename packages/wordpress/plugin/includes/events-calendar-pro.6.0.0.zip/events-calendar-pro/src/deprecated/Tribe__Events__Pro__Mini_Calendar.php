<?php
_deprecated_file( __FILE__, '6.0.0' );

/**
 * @deprecated 6.0.0
 */
class Tribe__Events__Pro__Mini_Calendar {

	public function __construct() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function get_month( $format = Tribe__Date_Utils::DBDATETIMEFORMAT ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function get_args() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function ajax_select_day() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}


	public function ajax_change_month() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function do_calendar( $args = array() ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function setup_list( $template_file ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function shutdown_list( $template_file ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function set_count( $query ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function set_taxonomies( $query ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function set_hidden( $query ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function ajax_change_month_set_date( $query ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function ajax_select_day_set_date( $query ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public static function instance() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}
}