<?php
_deprecated_file( __FILE__, '6.0.0' );

/**
 * @deprecated 6.0.0
 */
class Tribe__Events__Pro__Templates__Mods__List_View {
	public static function print_all_events_link() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}
}