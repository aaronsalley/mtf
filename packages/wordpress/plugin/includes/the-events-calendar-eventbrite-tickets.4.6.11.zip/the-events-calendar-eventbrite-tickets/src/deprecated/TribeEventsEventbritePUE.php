<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Tickets__Eventbrite__API' );


	class TribeEventsEventbritePUE extends Tribe__Events__Tickets__Eventbrite__PUE {

	}