<?php
_deprecated_file( __FILE__, '6.0.0' );

/**
 * @deprecated 6.0.0
 */
class Tribe__Events__Pro__Shortcodes__Events_List extends \Tribe\Events\Pro\Views\V2\Shortcodes\Shortcode_Tribe_Events_List {
	public function __construct() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function handle_shortcode_widget_taxonomy() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function get_term_id( $param, $taxonomy ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}
}