<?php
_deprecated_file( __FILE__, '6.0.0' );

/**
 * @deprecated 6.0.0
 */
class Tribe__Events__Pro__Shortcodes__Tribe_Events__Photo {

	public function __construct( Tribe__Events__Pro__Shortcodes__Tribe_Events $shortcode ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function filter_baseurl( $url ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function title_bar() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function shortcode_pre_render() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function shortcode_post_render() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}
}