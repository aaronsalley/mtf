<?php

class Tribe__Events__Tickets__Eventbrite__PUE__Helper {

	/**
	 * @var string Helper data
	 */
	const DATA = 'b800fa5f1187e4e271ff0cf972962a073c2f3ecf';

}
