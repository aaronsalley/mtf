<?php

_deprecated_file( __FILE__, '3.10.1', 'Tribe__Events__Tickets__Eventbrite__Template' );
class Tribe_Events_EventBrite_Template extends Tribe__Events__Tickets__Eventbrite__Template {}
