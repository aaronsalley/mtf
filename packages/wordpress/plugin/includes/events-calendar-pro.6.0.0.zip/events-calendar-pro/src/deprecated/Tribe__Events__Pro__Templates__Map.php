<?php
_deprecated_file( __FILE__, '6.0.0' );

/**
 * @deprecated 6.0.0
 */
class Tribe__Events__Pro__Templates__Map extends Tribe__Events__Pro__Template_Factory {

	public function header_attributes( $attrs ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function ajax_response() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}
}