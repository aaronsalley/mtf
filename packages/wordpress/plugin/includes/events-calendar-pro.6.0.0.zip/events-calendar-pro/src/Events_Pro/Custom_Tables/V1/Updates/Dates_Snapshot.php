<?php
/**
 * ${CARET}
 *
 * @since   6.0.0
 *
 * @package TEC\Events_Pro\Custom_Tables\V1\Updates;
 */

namespace TEC\Events_Pro\Custom_Tables\V1\Updates;

/**
 * Class Dates_Snapshot.
 *
 * @since   6.0.0
 *
 * @package TEC\Events_Pro\Custom_Tables\V1\Updates;
 */
class Dates_Snapshot {

}